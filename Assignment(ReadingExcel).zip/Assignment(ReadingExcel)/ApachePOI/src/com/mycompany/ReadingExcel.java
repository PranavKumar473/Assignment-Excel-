package com.mycompany;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

class Employee {
    private String name;
    private String position;
    private long hoursWorked;
    private int consecutiveDays;
    private double timeBetweenShifts;

    public Employee(String name, String position, long hoursWorked) {
        this.name = name;
        this.position = position;
        this.hoursWorked = hoursWorked;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public long getHoursWorked() {
        return hoursWorked;
    }

    public int getConsecutiveDays() {
        return consecutiveDays;
    }

    public void setConsecutiveDays(int consecutiveDays) {
        this.consecutiveDays = consecutiveDays;
    }

    public double getTimeBetweenShifts() {
        return timeBetweenShifts;
    }

    public void setTimeBetweenShifts(double timeBetweenShifts) {
        this.timeBetweenShifts = timeBetweenShifts;
    }
}


public class ReadingExcel {

    public static void main(String[] args) throws IOException, ParseException {
        String excelFilePath = "C:\\Users\\prana\\Documents\\workspace-spring-tool-suite-4-4.19.0.RELEASE\\ApachePOI\\datafiles\\Assignment_Timecard.xlsx";

        FileInputStream inputStream = new FileInputStream(excelFilePath);

        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheet("Sheet1");

        int lrow = sheet.getLastRowNum();

        Map<String, Date> prevShiftEndTime = new HashMap<>();
        Map<String, Integer> consecutiveDays = new HashMap<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

        List<Employee> employees = new ArrayList<>();

        for (int r = 1; r <= lrow; r++) {
            Row row = sheet.getRow(r);

            String employeeName = row.getCell(7).getStringCellValue();
            String position = row.getCell(0).getStringCellValue();
            Cell timeInCell = row.getCell(2);
            Cell timeOutCell = row.getCell(3);

            if (timeInCell == null || timeOutCell == null) {
                continue;
            }

            String timeInValue;
            String timeOutValue;

            if (timeInCell.getCellType() == CellType.NUMERIC) {
                if (DateUtil.isCellDateFormatted(timeInCell)) {
                    Date date = timeInCell.getDateCellValue();
                    timeInValue = dateFormat.format(date);
                } else {
                    timeInValue = NumberToTextConverter.toText(timeInCell.getNumericCellValue());
                }
            } else if (timeInCell.getCellType() == CellType.STRING) {
                timeInValue = timeInCell.getStringCellValue();
            } else {
                continue;
            }

            if (timeOutCell.getCellType() == CellType.NUMERIC) {
                if (DateUtil.isCellDateFormatted(timeOutCell)) {
                    Date date = timeOutCell.getDateCellValue();
                    timeOutValue = dateFormat.format(date);
                } else {
                    timeOutValue = NumberToTextConverter.toText(timeOutCell.getNumericCellValue());
                }
            } else if (timeOutCell.getCellType() == CellType.STRING) {
                timeOutValue = timeOutCell.getStringCellValue();
            } else {
                continue;
            }

            if (timeInValue.isEmpty() || timeOutValue.isEmpty()) {
                continue;
            }

            Date timeIn = dateFormat.parse(timeInValue);
            Date timeOut = dateFormat.parse(timeOutValue);

            long hoursWorked = (timeOut.getTime() - timeIn.getTime()) / (1000 * 60 * 60);

            Employee employee = new Employee(employeeName, position, hoursWorked);
            employees.add(employee);

            if (!prevShiftEndTime.containsKey(employeeName)) {
                prevShiftEndTime.put(employeeName, timeOut);
                continue; // Skip further processing for the first shift
            }

            long timeBetweenShiftsMillis = timeIn.getTime() - prevShiftEndTime.get(employeeName).getTime();
            double timeBetweenShiftsHours = timeBetweenShiftsMillis / (60 * 60 * 1000);

            if (consecutiveDays.containsKey(employeeName)) {
                int days = consecutiveDays.get(employeeName);

                if (timeBetweenShiftsHours < 24) {
                    days++;
                } else {
                    days = 1;
                }
                consecutiveDays.put(employeeName, days);

                if (days >= 7) {
                    employee.setConsecutiveDays(days);
                }
            } else {
                consecutiveDays.put(employeeName, 1);
            }
            
            // Check for less than 10 hours between shifts
            if (timeBetweenShiftsHours > 1 && timeBetweenShiftsHours < 10) {
                System.out.println("Name: " + employee.getName() + ", Position: " + employee.getPosition()
                        + " - Less than 10 hours between shifts");
            }

            prevShiftEndTime.put(employeeName, timeOut);
        }

        // Sort employees based on the order of your requirements
        employees.sort(Comparator
                .comparing(Employee::getConsecutiveDays, Comparator.reverseOrder())
                .thenComparing(Employee::getTimeBetweenShifts)
                .thenComparing(Employee::getHoursWorked, Comparator.reverseOrder()));

        // Display employees in the desired order
        for (Employee employee : employees) {
            if (employee.getConsecutiveDays() >= 7) {
                System.out.println("Name: " + employee.getName() + ", Position: " + employee.getPosition()
                        + " - Worked for 7 consecutive days");
            }
        }
        for (Employee employee : employees) {
            if (employee.getHoursWorked() > 14) {
                System.out.println("Name: " + employee.getName() + ", Position: " + employee.getPosition()
                        + " - Worked for more than 14 hours in a single shift");
            }
        }

        workbook.close();
    }
}


